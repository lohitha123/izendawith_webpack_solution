﻿export abstract class EventBase {
    //Silence is Gold
}