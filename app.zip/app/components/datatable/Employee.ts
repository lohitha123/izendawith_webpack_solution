﻿export class Employee {
    id: string;
    name: string;
    salary: number;
    address: string;
    USERNAME: string;
    USER_ID: string;
    PROFILE_ID: string;
    ORG_GROUP_ID: string;
    LDAP_ROLE: string;
    PASSHASH: string;
    PASSHASH_REQUIRED: string;
    //setupitems
    ORG_GROUP_NAME: string;
    //ORG_GROUP_ID: string;
    ITEM_ID: string;
    SHORT_DESCR: string;
    VENDOR_ID: string;
    VEND_ITEM_ID: string;
    UNIT_OF_PROCUREMENT: string;
    UNIT_OF_ISSUE: string;
    CONV_FACTOR: string;
    ITEM_PRICE: string;
    STATUS: number;
    LOT_CONTROLLED: string;
    SERIAL_CONTROLLED: string;
    IMPLANT_FLAG: string;
    CONV_FACTOR1: string;
    LATEX_FREE: string;
    REPLENISHMENT_TYPE: string;
    LEAD_TIME: string;
    PHARMACY_FLG: boolean;
    SUBSTITUTE_ITEM_FLG: boolean;
    EVERIFY_FLG: string;
    //setup inventory
    ORG_ID: string;
    INV_ITEM_ID: string;
    UOM: string;
    STOR_LOC: string;
    DEFAULT_LOC_FLAG: string;
    QUANTITY_ON_HAND: string;
    LAST_UPDATE_DATE: string;
    //REPLENISHMENT_TYPE: string;
    //STATUS: string;
    //SHORT_DESCR: string;
    //Bunits
    BUSINESS_UNIT: string;
    BU_TYPE: string;
    DESCR: string;
    //sub items
    PRIORITY: string;
    COLUMN_HEADER: string

}