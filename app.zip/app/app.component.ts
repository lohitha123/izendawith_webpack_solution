﻿import { Component } from '@angular/core';
import { TokenEntry_Enum } from './Shared/AtParEnums';
import { Menus } from './AtPar/Menus/routepath';
import { LeftBarAnimationService } from './Home/leftbar-animation.service';
import { AtParConstants } from './Shared/AtParConstants';
import { Title } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Router, NavigationStart, RoutesRecognized, NavigationEnd } from '@angular/router';
@Component({
    selector: 'my-app',
    templateUrl: 'app.component.html'
    

    
})
export class AppComponent {
   
    routerCounter: number;
    _deviceTokenEntry: string[] = [];

    constructor(
        private leftBarAnimateService: LeftBarAnimationService,
        private atParConstant: AtParConstants,
        private title: Title,
        private router: Router,
    ) {
        this.routerCounter = 0;
        this.subscribeRouterEvents();
    }

    subscribeRouterEvents() {
        this.router.events.subscribe(async (event) => {
            if (event instanceof NavigationStart) {
                if (localStorage.getItem('DeviceTokenEntry') != null && localStorage.getItem('DeviceTokenEntry') != undefined) {
                    this._deviceTokenEntry = JSON.parse(localStorage.getItem("DeviceTokenEntry"));
                }
                if (this.routerCounter == 0) {
                    this.routerCounter = 1;
                    if (localStorage.getItem('DeviceTokenEntry') == null || localStorage.getItem('DeviceTokenEntry') == undefined) {
                        if (event.url != '/pagenotfound' && event.url != '/forgot-password' && event.url != '/login' && !event.url.startsWith('/login?systemid=') && event.url != '/') {
                            this.router.navigate(['login']);
                        }
                    }
                    else {
                        if (this._deviceTokenEntry[TokenEntry_Enum.UserID] == null || this._deviceTokenEntry[TokenEntry_Enum.UserID] == undefined || this._deviceTokenEntry[TokenEntry_Enum.UserID] == '') {
                            if (event.url != '/pagenotfound' && event.url != '/forgot-password' && event.url != '/login' && !event.url.startsWith('/login?systemid=') && event.url != '/') {
                                this.router.navigate(['login']);
                            }
                        }
                        else {
                            if (event.id != 1) {
                                if (event.url == '/pagenotfound' || event.url == '/forgot-password' || event.url == '/login' || event.url.startsWith('/login?systemid=') || event.url == '/') {
                                    this.router.navigate(['atpar']);
                                }
                                else if (event.url != '/atpar') {
                                    localStorage.setItem('isAtParDashboard', 'NO');
                                }
                            }
                            else {
                                if (event.url == '/pagenotfound' || event.url == '/forgot-password' || event.url == '/login' || event.url.startsWith('/login?systemid=') || event.url == '/') {
                                    localStorage.clear();
                                }
                                else if (event.url != '/atpar') {
                                    localStorage.setItem('isAtParDashboard', 'NO');

                                }
                            }
                        }
                    }
                }
            }
            else if (event instanceof RoutesRecognized) {
            }
            else if (event instanceof NavigationEnd) {
                this.routerCounter = 0;
                this._deviceTokenEntry = [];
            }
        });

        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {

                let subMenu: Menus = new Menus();
                var appName: string = localStorage.getItem('activeGroupModuleName');
                var menuItems: Menus[] = JSON.parse(localStorage.getItem('MenuList')) as Menus[];

                if (event.url != '/atpar') {
                    if (menuItems != null && menuItems != undefined) {
                        for (var i = 0; i < menuItems.length; i++) {
                            if (event.url.indexOf(menuItems[i].ROUTE) >= 0 && appName == menuItems[i].APP_NAME) {
                                subMenu = menuItems[i];
                                break;
                            }
                        }

                        localStorage.setItem('submenu', JSON.stringify(subMenu));
                        this.title.setTitle(AtParConstants.PRODUCT_NAME + ' - ' + subMenu.MENU_NAME);
                    }
                    else {
                        this.title.setTitle(AtParConstants.PRODUCT_NAME + ' - ' + 'Dashboard');

                    }
                }
                else {
                    this.title.setTitle(AtParConstants.PRODUCT_NAME + ' - Dashboard');
                }



            }
        });
    }

}
