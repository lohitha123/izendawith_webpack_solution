﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-item-usage-report.component.html'
})

export class ItemUsageReportComponent {

} 