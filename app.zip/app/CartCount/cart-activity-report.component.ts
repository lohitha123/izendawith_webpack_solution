﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-activity-report.component.html'
})

export class ActivityReportComponent {

} 