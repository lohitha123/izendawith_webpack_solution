﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-par-audit-report.component.html'
})

export class ParAuditReportComponent {

} 