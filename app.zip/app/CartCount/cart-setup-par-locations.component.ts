﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';

@Component({
    templateUrl: 'cart-setup-par-locations.component.html'
})

export class SetupParLocationsComponent {
    cartAppId: number = EnumApps.CartCount;
} 