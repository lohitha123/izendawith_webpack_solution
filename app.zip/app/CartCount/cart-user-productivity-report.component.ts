﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-user-productivity-report.component.html'
})

export class UserProductivityReportComponent {

} 