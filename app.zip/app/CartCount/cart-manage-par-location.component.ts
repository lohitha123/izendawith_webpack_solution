﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-manage-par-location.component.html'
})

export class ManageParLocationComponent {

} 