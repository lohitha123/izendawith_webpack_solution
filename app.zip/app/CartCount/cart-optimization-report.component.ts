﻿
import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-optimization-report.component.html'
})

export class OptimizationReportComponent {

} 