﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-manage-orders.component.html'
})

export class ManageOrdersComponent {

} 