﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'cartcount.component.html'
})


export class CartCountComponent { }