﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-daily-user-activity.component.html'
})

export class DailyUserActivityComponent {

} 