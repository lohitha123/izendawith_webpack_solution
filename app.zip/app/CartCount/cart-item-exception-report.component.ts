﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-item-exception-report.component.html'
})

export class ItemExceptionReportComponent {

} 