﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-cart-averages-report.component.html'
})

export class CartAveragesReportsComponent {

} 