﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-order-history-report.component.html'
})

export class OrderHistoryReportComponent {

} 