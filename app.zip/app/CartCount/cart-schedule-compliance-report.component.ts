﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-schedule-compliance-report.component.html'
})

export class ScheduleComplianceReportComponent {

} 