﻿import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Http, Response } from "@angular/http";
import { MT_ATPAR_ORG_GROUP_BUNITS } from "../Entities/MT_ATPAR_ORG_GROUP_BUNITS";
import { MT_ATPAR_ORG_GROUPS } from "../Entities/MT_ATPAR_ORG_GROUPS";
import { VM_CART_SCHEDULES } from '../Entities/VM_CART_SCHEDULES';
import { MT_CRCT_PAR_LOC_SCHEDULE_DETAILS } from '../Entities/MT_CRCT_PAR_LOC_SCHEDULE_DETAILS';
import { MT_ATPAR_SCHEDULE_HEADER } from '../Entities/MT_ATPAR_SCHEDULE_HEADER';
//import { AtParKeyValuePair } from '../../app/Entities/atparkeyvaluepair';
import { Message } from './../components/common/api';
import { AtParWebApiResponse } from '../Shared/AtParWebApiResponse';
//import { CustomValidators } from '../common/textbox/custom-validators';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpService } from '../Shared/HttpService';
import { SelectItem } from './../components/common/api';
import { AtparStatusCodes } from '../Shared/AtParStatusCodes';
import { BusinessType, StatusType, TokenEntry_Enum, ClientType } from '../Shared/AtParEnums'
import { CartProcessServices } from './cart-process-parameters.service';
//import { ATPAR_VALIDATION_RULES } from '../entities/atpar_validation_rules';
//import { CustomValidations } from '../common/validations/customvalidation';
import { SpinnerService } from '../components/spinner/event.spinner.service';
import { List, Enumerable } from 'linqts';
import { asEnumerable } from 'linq-es5';
import { AtParCommonService } from '../Shared/atpar-common.service';

import { AtParConstants } from '../Shared/AtParConstants';
import { DataTable } from '../components/datatable/datatable';
@Component({
    templateUrl: 'cart-process-parameters.component.html',
    providers: [CartProcessServices, AtParCommonService, HttpService, AtParConstants],


})

export class ProcessParametersComponent {

    @ViewChild(DataTable) dataTableComponent: DataTable;
    growlMessage: Message[] = [];
    deviceTokenEntry: string[] = [];
    //  statusCode: number = -1;
    statusType: number = -1;
    lstScheduleDetails: MT_CRCT_PAR_LOC_SCHEDULE_DETAILS[];
    lstCheckedParLocation: Array<VM_CART_SCHEDULES>;
    startIndex: number;
    EndIndex: number;
    //ALL: string = "ALL"


    // hasMultipleOrgGroups = false;


    //  lstBunitslist: any[];
    pageSize: number;
    statusMesssage: string;
    lstGridData: VM_CART_SCHEDULES[];
    lstGridData1 = new VM_CART_SCHEDULES();
    CartIdSearchLst: VM_CART_SCHEDULES[];
    lstgridfilterData: VM_CART_SCHEDULES[] = null;
    lstScheduleData: MT_ATPAR_SCHEDULE_HEADER[];
    ddlSchedId: SelectItem[] = [];
    ddlmodeldata: any;
    ddlSelectedProcessData = new MT_ATPAR_SCHEDULE_HEADER();
    autoCompleteCartID: string = "";

    showGrid: boolean = false;
    //  bind  Orggroup
    ddlShowOrgGroupDD: boolean = false;
    blnShowOrgGroupLabel: boolean = false;
    selectedOrgGroupId: string = "";
    // lstOrgGroupData: any;
    lstOrgGroupData: SelectItem[] = [];
    orgGroupList: MT_ATPAR_ORG_GROUPS[];
    lblOrgGroupId: string;
    ddlBusinessData: SelectItem[] = [];
    businessDatangModel: string = "";
    previousSelected: string = '';
    lstBusinessData: MT_ATPAR_ORG_GROUP_BUNITS[];
    ALL: string = "ALL"
    rowPageOptions: any[];
    orgGroupIDForDBUpdate: string;
    blnsortbycolumn: boolean = true;

    constructor(private httpService: HttpService,
        private cartProcessServices: CartProcessServices,
        private spinnerService: SpinnerService,
        private commonService: AtParCommonService,
        private atParConstant: AtParConstants


    ) {

    }

    async ngOnInit() {

        try {
            this.spinnerService.start();
            this.deviceTokenEntry = JSON.parse(localStorage.getItem("DeviceTokenEntry"));
            this.startIndex = + sessionStorage.getItem("Recordsstartindex");
            this.EndIndex = + sessionStorage.getItem("RecordsEndindex");
            this.lstCheckedParLocation = new Array<VM_CART_SCHEDULES>();
            this.bindOrgGroups();
            //this.bindBunits();
            this.rowPageOptions = [];
            this.rowPageOptions = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
            this.ddlSchedId = [];
            this.pageSize = + this.deviceTokenEntry[TokenEntry_Enum.RecordsPerPage];
            this.spinnerService.start();

        }

        catch (ex) {
            this.clientErrorMsg(ex);
        }
    }

    clientErrorMsg(strExMsg) {
        this.growlMessage = [];
        this.atParConstant.catchClientError(this.growlMessage, this.spinnerService, strExMsg.toString());
    }


    async bindOrgGroups() {
        try {
            this.spinnerService.start();

            await this.commonService.getUserOrgGroups(this.deviceTokenEntry[TokenEntry_Enum.UserID],
                this.deviceTokenEntry[TokenEntry_Enum.OrgGrpID]).
                catch(this.httpService.handleError).then((res: Response) => {
                    let data = res.json() as AtParWebApiResponse<MT_ATPAR_ORG_GROUPS>;
                    this.spinnerService.stop();
                    this.growlMessage = [];

                    switch (data.StatType) {
                        case StatusType.Success: {
                            this.orgGroupList = data.DataList;
                            this.ddlBusinessData.push({ label: "select OrgID ", value: "" })

                            if (this.orgGroupList.length == 1) {

                                this.blnShowOrgGroupLabel = true;
                                this.lblOrgGroupId = this.orgGroupList[0].ORG_GROUP_ID + "-" + this.orgGroupList[0].ORG_GROUP_NAME;
                                this.selectedOrgGroupId = this.orgGroupList[0].ORG_GROUP_ID;
                                this.populateBusinessUnits();

                                break;

                            }
                            else if (this.orgGroupList.length > 1) {
                                this.ddlShowOrgGroupDD = true;
                                //this.lstOrgGroupData = [];
                                this.lstOrgGroupData.push({ label: "Select OrgGroupID", value: "" })
                                for (var i = 0; i < this.orgGroupList.length; i++) {
                                    //if (this.orgGroupList[i].ORG_GROUP_ID !== "All") { ORG_GROUP_ID
                                    this.lstOrgGroupData.push({ label: this.orgGroupList[i].ORG_GROUP_ID + "-" + this.orgGroupList[i].ORG_GROUP_NAME, value: this.orgGroupList[i].ORG_GROUP_NAME })

                                    
                                    // }
                                }

                                break;
                            }
                            break;
                        }
                        case StatusType.Warn: {
                            this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: data.StatusMessage });
                            break;
                        }
                        case StatusType.Error: {
                            this.growlMessage.push({ severity: 'error', summary: AtParConstants.GrowlTitle_Error, detail: data.StatusMessage });
                            break;
                        }
                        case StatusType.Custom: {
                            this.growlMessage.push({ severity: 'info', summary: AtParConstants.GrowlTitle_Info, detail: data.StatusMessage });
                            break;
                        }
                    }

                });
            this.spinnerService.stop();

        }
        catch (ex) {
            this.clientErrorMsg(ex);
        }
    }

    async ddlOrgGrpIdChanged(event) {
        try {
            this.businessDatangModel = "";
            this.ddlBusinessData = [];
            this.growlMessage = [];
            this.ddlBusinessData.push({ label: "Select Org ID ", value: "" })
            if (this.selectedOrgGroupId == "Select OrgGroupID" || this.selectedOrgGroupId == "") {
                //this.ddlBusinessData = [];


                this.showGrid = false;
                return;
            }
            if (this.previousSelected == "" || event.label != this.previousSelected) {

                this.previousSelected = this.selectedOrgGroupId;
                this.spinnerService.start();
                this.populateBusinessUnits();
                this.spinnerService.stop();
            }
        }
        catch (ex) {
            this.clientErrorMsg(ex);
        }


    }


    async populateBusinessUnits(): Promise<boolean> {

        // this.lstBusinessData = [];
        let isOrgBUnitsExist: boolean = false;
        this.showGrid = false;
        try {
            if (this.blnShowOrgGroupLabel == true) {

                this.orgGroupIDForDBUpdate = this.lblOrgGroupId.split("-")[0];
            }
            else {
                this.orgGroupIDForDBUpdate = this.selectedOrgGroupId;
            }
            this.spinnerService.start();
            await this.commonService.getOrgBusinessUnits(this.orgGroupIDForDBUpdate, BusinessType.Inventory).
                catch(this.httpService.handleError).then((res: Response) => {
                    let data = res.json() as AtParWebApiResponse<MT_ATPAR_ORG_GROUP_BUNITS>;
                    this.spinnerService.stop();
                    // this.growlMessage = [];
                    //this.ddlBusinessData.push({ label: "Select OrgId ", value: "" })
                    switch (data.StatType) {
                        case StatusType.Success: {
                            this.lstBusinessData = data.DataList;
                            if (this.lstBusinessData.length > 0) {
                                for (let i = 0; i < this.lstBusinessData.length; i++) {
                                    this.ddlBusinessData.push({ label: this.lstBusinessData[i].toString(), value: this.lstBusinessData[i].toString() })

                                }
                            }
                            //} else {
                            //    this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: "No Assigned Org Business Units" });
                            //    isOrgBUnitsExist = false;
                            //    break;
                            //}


                            isOrgBUnitsExist = true;
                            break;
                        }
                        case StatusType.Warn: {
                            // this.showGrid = false;
                            this.growlMessage = []
                            this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: data.StatusMessage });
                            isOrgBUnitsExist = false;
                            break;
                        }
                        case StatusType.Error: {
                            this.growlMessage = []
                            //this.showGrid = false;
                            this.growlMessage.push({ severity: 'error', summary: AtParConstants.GrowlTitle_Error, detail: data.StatusMessage });
                            isOrgBUnitsExist = false;
                            break;
                        }
                        case StatusType.Custom: {
                            this.growlMessage = []
                            // this.showGrid = false;
                            this.growlMessage.push({ severity: 'info', summary: AtParConstants.GrowlTitle_Info, detail: data.StatusMessage });
                            isOrgBUnitsExist = false;
                            break;
                        }
                    }

                });
            this.spinnerService.stop();

            return Promise.resolve(isOrgBUnitsExist);
        }
        catch (ex) {
            this.clientErrorMsg(ex);
        }
    }


    searchAutoCompleteCartIdName(event) {
        //try {
        let query = event.query;
        this.CartIdSearchLst = this.lstGridData;
        this.CartIdSearchLst = this.filterCartIdNames(query, this.CartIdSearchLst)

        //} catch (ex) {

        //    this.clientErrorMsg(ex);
        //}
    }

    filterCartIdNames(query, cartIdNames: any[]): any[] {
        //try {
        let filtered : any[] = [];
        if (query == "%") {
            for (let i = 0; i < cartIdNames.length; i++) {
                let cartIdNamesValue = cartIdNames[i];
                filtered.push(cartIdNamesValue.CART_ID);
            }

        } else {
            if (query.length >= 1) {
                for (let i = 0; i < cartIdNames.length; i++) {
                    let cartIdNamesValue = cartIdNames[i];
                    if (cartIdNamesValue.CART_ID.toString().toUpperCase().indexOf(query.toString().toUpperCase()) == 0) {
                        filtered.push(cartIdNamesValue.CART_ID);
                    }
                }
            }
        }

        return filtered;
        //}
        //catch (ex) {
        //    this.clientErrorMsg(ex);

        //}

    }



    async  btnGo_Click() {

       
        try {

            if (this.ddlShowOrgGroupDD) {
                if (this.selectedOrgGroupId == null || this.selectedOrgGroupId == undefined || this.selectedOrgGroupId == "") {
                    this.showGrid = false;
                    this.growlMessage = [];
                    this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: "Please select Org Group ID" });
                    return;
                }
            }
            if (this.businessDatangModel == "" || this.businessDatangModel == "0" || this.businessDatangModel == null) {
                this.showGrid = false;
                this.growlMessage = [];
                this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: "Please select Org ID" });
                return;
            }

            await this.PopulateCarts();
        }

        catch (ex) {
            this.clientErrorMsg(ex);

        }


    }




    async  PopulateCarts() {

        this.showGrid = false
        ////    if (this.showGrid == true) {
        ////    this.dataTableComponent.reset();

        ////}
        this.growlMessage = [];
        try {
            let orgGroupId: string;
            if (this.blnShowOrgGroupLabel) {
                orgGroupId = this.lblOrgGroupId;
            } else {
                orgGroupId = this.selectedOrgGroupId;
            }
            if (this.deviceTokenEntry[TokenEntry_Enum.OrgGrpID] != "ALL") {
                orgGroupId = this.deviceTokenEntry[TokenEntry_Enum.OrgGrpID];
            }

            this.spinnerService.start();
            await this.cartProcessServices.GetProcessParametersCarts(orgGroupId,
                this.businessDatangModel, this.autoCompleteCartID, this.deviceTokenEntry[TokenEntry_Enum.UserID])
                .subscribe(responses => {
                    this.spinnerService.stop();
                    switch (responses.StatType) {
                        case StatusType.Success: {

                            this.lstGridData = new Array<VM_CART_SCHEDULES>();
                            let dataList = responses.DataList;

                            for (let x = 0; x < dataList.length; x++) {
                                if (dataList[x].ASSIGN_CART == "Y") {
                                    dataList[x].ASSIGN_CART = true;
                                }

                                else {

                                    dataList[x].ASSIGN_CART = false;
                                }
                                this.lstGridData1 = new VM_CART_SCHEDULES();
                                this.lstGridData1.CART_ID = dataList[x].CART_ID;

                                this.lstGridData1.BUSINESS_UNIT = dataList[x].BUSINESS_UNIT;
                                this.lstGridData1.ASSIGN_CART = dataList[x].ASSIGN_CART;
                                this.lstGridData1.SCHEDULER = dataList[x].SCHEDULER;

                                this.lstGridData.push(this.lstGridData1);

                            }

                            this.lstGridData = asEnumerable(this.lstGridData).OrderByDescending(x => x.ASSIGN_CART).ToArray();
                            let sortedUnCheckedData = asEnumerable(this.lstGridData).OrderBy(x => x.ASSIGN_CART).ToArray();
                            this.lstGridData = new Array<VM_CART_SCHEDULES>();
                            this.lstGridData = sortedUnCheckedData.reverse();
                            if (this.lstGridData.length >= 1) {

                                this.growlMessage = [];


                                this.showGrid = true;


                            }

                            else {

                                //this.growlMessage = [];
                                // this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: "No Data Found " });
                                this.showGrid = false;
                            }
                            break;
                        }

                        case StatusType.Error:
                            {
                                this.growlMessage = [];
                                this.statusMesssage = responses.StatusMessage;
                                this.growlMessage.push({ severity: 'error', summary: AtParConstants.GrowlTitle_Error, detail: responses.StatusMessage });
                                this.showGrid = false;
                                break;
                            }
                        case StatusType.Warn:
                            {
                                this.growlMessage = [];
                                this.statusMesssage = responses.StatusMessage;
                                this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: responses.StatusMessage });
                                this.showGrid = false;
                                break;
                            }
                        case StatusType.Custom:
                            {
                                this.growlMessage = [];
                                this.statusMesssage = responses.StatusMessage;
                                this.growlMessage.push({ severity: 'info', summary: AtParConstants.GrowlTitle_Info, detail: responses.StatusMessage });
                                this.showGrid = false;
                                break;
                            }
                    }
                });
            this.getSheduleIds();
            this.spinnerService.stop();
        }
        catch (ex) {
            this.clientErrorMsg(ex);
        }

    }





    async   getSheduleIds() {

        try {
            let orgGroupId: string;
            if (this.blnShowOrgGroupLabel) {
                orgGroupId = this.lblOrgGroupId;
            } else {
                orgGroupId = this.selectedOrgGroupId;
            }
            if (this.deviceTokenEntry[TokenEntry_Enum.OrgGrpID] != "ALL") {
                orgGroupId = this.deviceTokenEntry[TokenEntry_Enum.OrgGrpID];
            }
            this.spinnerService.start();
            await this.cartProcessServices.GetSheduleIdata(orgGroupId)
                .forEach(response => {
                    this.spinnerService.stop();
                    switch (response.StatType) {
                        case StatusType.Success:
                            {
                                this.ddlSchedId = [];
                                this.ddlSchedId.push({ label: "Select one", value: "" })
                                this.lstScheduleData = response.DataList;
                                for (let i = 0; i < this.lstScheduleData.length; i++) {
                                    this.ddlSchedId.push({ label: this.lstScheduleData[i].SCHEDULE_ID, value: this.lstScheduleData[i].SCHEDULE_ID })
                                }
                                break;
                            }

                        case StatusType.Error:
                            {
                                this.statusMesssage = response.StatusMessage;
                                this.growlMessage.push({ severity: 'error', summary: AtParConstants.GrowlTitle_Error, detail: response.StatusMessage });
                                break;
                            }
                        case StatusType.Warn:
                            {
                                this.statusMesssage = response.StatusMessage;
                                this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: response.StatusMessage });
                                break;
                            }
                        case StatusType.Custom:
                            {
                                this.statusMesssage = response.StatusMessage;
                                this.growlMessage.push({ severity: 'info', summary: AtParConstants.GrowlTitle_Info, detail: response.StatusMessage });
                                break;

                            }
                    }
                });
            this.spinnerService.stop();
        }

        catch (ex) {
            this.clientErrorMsg(ex);

        }



    }

    changeStatus(cartdata) {
        try {
            let lstCartSchedules = cartdata;

            // this.lstGridData = new Array<VM_CART_SCHEDULES>();

            for (let x = 0; x < lstCartSchedules.length; x++) {
                if (lstCartSchedules[x].ASSIGN_CART == true) {
                    lstCartSchedules[x].ASSIGN_CART = "1";
                }

                else {

                    lstCartSchedules[x].ASSIGN_CART = false;
                }
                this.lstGridData1 = new VM_CART_SCHEDULES();
                this.lstGridData1.CART_ID = lstCartSchedules[x].CART_ID;

                //this.lstGridData1.BUSINESS_UNIT = lstCartSchedules[x].BUSINESS_UNIT;
                this.lstGridData1.ASSIGN_CART = lstCartSchedules[x].ASSIGN_CART;
                this.lstGridData1.SCHEDULER = lstCartSchedules[x].SCHEDULER;
                this.lstGridData.push(this.lstGridData1);
            }
        }

        catch (ex) {
            this.clientErrorMsg(ex);
        }
    }

    async  btnSubmit_Click() {
        try {
            //this.growlMessage = [];
            this.spinnerService.start();
            if (this.lstGridData != null) {
                let data = this.lstGridData.filter(x => x.ASSIGN_CART == true && x.SCHEDULER == "");
                if (data == null || data.length > 0) {
                    this.spinnerService.stop();
                    this.growlMessage = [];
                    return this.growlMessage.push({ severity: "warn", summary: AtParConstants.GrowlTitle_Warn, detail: "Please select Inventory Schedule" })


                }
                var schedules = this.lstGridData;
                this.lstScheduleDetails = Array<MT_CRCT_PAR_LOC_SCHEDULE_DETAILS>();

                for (let x = 0; x < schedules.length; x++) {
                    let scheduleDetails = new MT_CRCT_PAR_LOC_SCHEDULE_DETAILS();
                    if (schedules[x].ASSIGN_CART == true) {
                        scheduleDetails.CHK_VALUE = "1";
                        scheduleDetails.PAR_LOC_ID = schedules[x].CART_ID
                        scheduleDetails.SCHEDULE_ID = schedules[x].SCHEDULER;
                        this.lstScheduleDetails.push(scheduleDetails);
                    }
                    else {
                        scheduleDetails.CHK_VALUE = "0";
                        scheduleDetails.PAR_LOC_ID = schedules[x].CART_ID
                        scheduleDetails.SCHEDULE_ID = schedules[x].SCHEDULER;
                        this.lstScheduleDetails.push(scheduleDetails);
                    }

                }
                this.spinnerService.start();
                await this.cartProcessServices.AssignScheduleToCarts(this.lstScheduleDetails, this.selectedOrgGroupId, this.businessDatangModel)
                    .catch(this.httpService.handleError).then((webresponse: Response) => {


                        let response = webresponse.json() as AtParWebApiResponse<MT_CRCT_PAR_LOC_SCHEDULE_DETAILS>;
                        // this.statusCode = response.StatusCode;
                        this.spinnerService.stop();
                        switch (response.StatType) {
                            case StatusType.Success:
                                {
                                    this.growlMessage = [];
                                    this.showGrid = false;
                                    this.businessDatangModel = '';
                                    this.selectedOrgGroupId = '';
                                    this.autoCompleteCartID = '';
                                    this.growlMessage.push({ severity: "success", summary: AtParConstants.GrowlTitle_Success, detail: "Updated successfully" })
                                    break;
                                }

                            case StatusType.Error:
                                {
                                    this.growlMessage = [];
                                    this.statusMesssage = response.StatusMessage;
                                    this.growlMessage.push({ severity: 'error', summary: AtParConstants.GrowlTitle_Error, detail: response.StatusMessage });
                                    break;
                                }
                            case StatusType.Warn:
                                {
                                    this.statusMesssage = response.StatusMessage;
                                    this.growlMessage.push({ severity: 'warn', summary: AtParConstants.GrowlTitle_Warn, detail: response.StatusMessage });


                                    break;
                                }
                            case StatusType.Custom:
                                {
                                    this.statusMesssage = response.StatusMessage;
                                    this.growlMessage.push({ severity: 'info', summary: AtParConstants.GrowlTitle_Info, detail: response.StatusMessage });


                                    break;
                                }



                        }
                    });
            }
            this.spinnerService.stop();
        }

        catch (ex) {

            this.clientErrorMsg(ex);
        }

    }


    public onSort1(event) {
        try {

            if (event.data != null && event.data.length > 0) {

                for (let x = 0; x < event.data.length; x++) {

                      event.data[x].ASSIGN_CART = false;
                    


                }


            }
        }
        catch (ex) {
            this.clientErrorMsg(ex);
        }

    }


    public onSort(event) {
        try {
            var element = event;
            this.blnsortbycolumn = !this.blnsortbycolumn;
            let checkedData = asEnumerable(this.lstGridData).Where(a => a.ASSIGN_CART == 1).ToArray();
            let unCheckedData = asEnumerable(this.lstGridData).Where(a => a.ASSIGN_CART == 0).ToArray();
            if (event.data != null && event.data.length > 0) {


                checkedData = checkedData.sort(function (a, b) {

                    if (a[element.field] < b[element.field])
                        return -1;
                    if (a[element.field] > b[element.field])
                        return 1;
                    return 0;
                });
                unCheckedData = unCheckedData.sort(function (a, b) {

                    if (a[element.field] < b[element.field])
                        return -1;
                    if (a[element.field] > b[element.field])
                        return 1;
                    return 0;
                });
                if (event.order == -1) {


                    this.lstGridData = checkedData.reverse().concat(unCheckedData.reverse());// sortedUnCheckedData.reverse();
                } else {

                    this.lstGridData = checkedData.concat(unCheckedData);
                }
            }
        } catch (exMsg) {
            this.spinnerService.stop();
            this.clientErrorMsg(exMsg);
        }

    }


    //checkAll1() {
    //    try {
    //        this.lstCheckedParLocation = [];
    //        this.EndIndex = +this.pageSize;
    //        if (this.EndIndex > this.lstGridData.length) {
    //            this.EndIndex = this.lstGridData.length;
    //        }
    //        for (let i = this.startIndex; i <= this.EndIndex - 1; i++) {
    //            this.lstGridData[i].ASSIGN_CART = true;
    //            this.lstCheckedParLocation.push(this.lstGridData[i]);

    //        }
    //    }
    //    catch (ex) {
    //        this.clientErrorMsg(ex);

    //    }


    //}

    //uncheckAll1() {

    //    try {
    //        this.lstCheckedParLocation = [];
    //        this.startIndex = + sessionStorage.getItem("Recordsstartindex");
    //        this.EndIndex = + this.pageSize;
    //        if (this.EndIndex > this.lstGridData.length) {
    //            this.EndIndex = this.lstGridData.length;
    //        }
    //        for (let i = this.EndIndex - 1; i >= this.startIndex; i--) {
    //            this.lstGridData[i].ASSIGN_CART = false;
    //            this.lstCheckedParLocation.push(this.lstGridData[i]);
    //        }

    //    }
    //    catch (ex) {
    //        this.clientErrorMsg(ex);
    //    }


    //}



    checkAll() {
        try {
            this.startIndex = + sessionStorage.getItem("Recordsstartindex");
            this.EndIndex = + sessionStorage.getItem("RecordsEndindex");

            if (this.lstgridfilterData != null || this.lstgridfilterData != undefined) {

                if (this.EndIndex > this.lstgridfilterData.length) {
                    this.EndIndex = this.lstgridfilterData.length;
                }

                for (let i = this.startIndex; i <= this.EndIndex - 1; i++) {
                    this.lstgridfilterData[i].ASSIGN_CART = true;


                }

            }
            else {
                if (this.EndIndex > this.lstGridData.length) {
                    this.EndIndex = this.lstGridData.length;
                }
                for (let i = this.startIndex; i <= this.EndIndex - 1; i++) {
                    this.lstGridData[i].ASSIGN_CART = true;


                }
            }
        } catch (ex) {
            this.spinnerService.stop();
            this.clientErrorMsg(ex);
        }
    }


    unCheckAll() {

        try {

            this.startIndex = + sessionStorage.getItem("Recordsstartindex");
            this.EndIndex = + sessionStorage.getItem("RecordsEndindex");

            if (this.lstgridfilterData != null || this.lstgridfilterData != undefined) {

                if (this.EndIndex > this.lstgridfilterData.length) {
                    this.EndIndex = this.lstgridfilterData.length;
                }

                for (let i = this.EndIndex - 1; i >= this.startIndex; i--) {
                    this.lstgridfilterData[i].ASSIGN_CART = false;
                }
            } else {
                if (this.EndIndex > this.lstGridData.length) {
                    this.EndIndex = this.lstGridData.length;
                }
                for (let i = this.EndIndex - 1; i >= this.startIndex; i--) {
                    this.lstGridData[i].ASSIGN_CART = false;


                }
            }
        }

        catch (ex) {
            this.spinnerService.stop();
            this.clientErrorMsg(ex);
        }
    }

    filterdata(event) {

        this.lstgridfilterData = new Array<VM_CART_SCHEDULES>();

        this.lstgridfilterData = event;

    }

    ngOnDestroy() {

        this.deviceTokenEntry = null;
        this.orgGroupList = null;

        this.CartIdSearchLst = null;
        this.growlMessage = null;
        this.lstGridData = null;
        this.lstScheduleData = null;
        this.lstGridData1 = null;
        this.growlMessage = null;
        this.lstGridData1 = null;
        this.spinnerService.stop();

        this.lstOrgGroupData = null;
        this.lblOrgGroupId = null;

        this.ddlBusinessData = null;
        this.businessDatangModel = null;

        this.previousSelected = null;
        this.lstBusinessData = null;
        this.orgGroupIDForDBUpdate = null;

    }

}