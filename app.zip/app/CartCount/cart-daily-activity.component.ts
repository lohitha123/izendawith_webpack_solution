﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-daily-activity.component.html'
})

export class DailyActivityComponent {

} 