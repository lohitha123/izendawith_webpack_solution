﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';

@Component({
    templateUrl: 'cart-user-parameters.component.html'
})

export class UserParametersComponent {
    crctAppId: number = EnumApps.CartCount;
} 