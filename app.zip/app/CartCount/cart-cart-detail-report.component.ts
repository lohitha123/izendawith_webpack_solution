﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-cart-detail-report.component.html'
})

export class CartDetailReportComponent {

} 