﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-cart-putaway-report.component.html'
})

export class CartPutawayReportComponent {

} 