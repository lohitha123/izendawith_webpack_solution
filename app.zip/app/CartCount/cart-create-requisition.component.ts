﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'cart-create-requisition.component.html'
})

export class CreateRequisitionComponent {

} 