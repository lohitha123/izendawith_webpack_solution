﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';
@Component({
  
    templateUrl: 'asmt-location-groups-allocation.component.html'
})

export class LocationGroupsAllocationComponent {
    assetManagementAppId: number = EnumApps.AssetManagement;
} 