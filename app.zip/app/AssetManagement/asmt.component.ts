﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'asmt.component.html'
})


export class AssetManagementComponent { }