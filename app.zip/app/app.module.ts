﻿
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import { BrowserModule, Title } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Router, NavigationStart, RoutesRecognized, NavigationEnd } from '@angular/router';
import { HttpModule, JsonpModule } from '@angular/http';
import { LocationStrategy, HashLocationStrategy, PathLocationStrategy, APP_BASE_HREF } from '@angular/common';

import { HttpService } from './Shared/HttpService';
import { AppComponent } from './app.component';
import { PageNotFoundComponent } from './AtPar/atpar-page-not-found.component';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './Shared/shared.module';
import { SpinnerModule } from './components/spinner/spinner.module';
import { IzendaIntegrate } from './_helpers/izendaintegrate';
import { TokenEntry_Enum } from './Shared/AtParEnums';
import { Menus } from './AtPar/Menus/routepath';
import { LeftBarAnimationService } from './Home/leftbar-animation.service';
import { AtParConstants } from './Shared/AtParConstants';

@NgModule({

    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        JsonpModule,
        RouterModule,
        SharedModule.forRoot(),
        SpinnerModule,
        AppRoutingModule,
    ],
    declarations: [
        AppComponent,
        PageNotFoundComponent
    ],

    bootstrap: [AppComponent],

    schemas: [CUSTOM_ELEMENTS_SCHEMA],

    providers: [
        Title,
        HttpService, IzendaIntegrate, AtParConstants,
        { provide: APP_BASE_HREF, useValue: '/' },
        //{ provide: LocationStrategy, useClass: PathLocationStrategy },
        { provide: LocationStrategy, useClass: HashLocationStrategy },
    ]

})
export class AppModule {

  

}
