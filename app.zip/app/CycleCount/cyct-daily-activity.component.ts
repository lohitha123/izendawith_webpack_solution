﻿import { Component } from '@angular/core';

@Component({

    templateUrl: 'cyct-daily-activity.component.html'
})

export class DailyActivityComponent {

}