﻿import { Component } from '@angular/core';

@Component({

    templateUrl: 'cyct-event-summary-report.component.html'
})

export class EventSummaryReportComponent {

}