﻿import { Component } from '@angular/core';

@Component({

    templateUrl: 'cyct-item-exception-report.component.html'
})

export class ItemExceptionReportComponent {

}