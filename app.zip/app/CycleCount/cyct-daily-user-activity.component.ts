﻿import { Component } from '@angular/core';

@Component({

    templateUrl: 'cyct-daily-user-activity.component.html'
})

export class DailyUserActivityComponent {

}