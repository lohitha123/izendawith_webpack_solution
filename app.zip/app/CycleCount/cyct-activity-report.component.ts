﻿import { Component } from '@angular/core';

@Component({

    templateUrl: 'cyct-activity-report.component.html'
})
export class ActivityReportComponent {

}