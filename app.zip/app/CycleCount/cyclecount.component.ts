﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'cyclecount.component.html'
})


export class CycleCountComponent { }