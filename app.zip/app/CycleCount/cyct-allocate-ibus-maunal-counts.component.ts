﻿
import { Component } from '@angular/core';
import { datatableservice } from '../components/datatable/datatableservice';
import { Employee } from '../components/datatable/employee';
@Component({
    templateUrl: 'cyct-allocate-ibus-maunal-counts.component.html',
    providers: [datatableservice]
})

export class AllocateIBUsManualCountsComponent {
    isVisible: boolean = false;
    lstDBdata: Employee[];
    constructor(public datatableservice: datatableservice)
    {

    }
    getAllBunits()
    {
        this.isVisible = true;
        this.datatableservice.getBunits().then(bUnitsdata => { this.lstDBdata = bUnitsdata; });
    }
}