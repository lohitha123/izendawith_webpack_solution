﻿import { NgModule } from '@angular/core';
import { RouterModule, Routes, UrlSerializer } from '@angular/router';

import { LoginComponent } from './login/index';
import { PageNotFoundComponent } from './AtPar/atpar-page-not-found.component';

import { DefaultUrlSerializer, UrlTree } from '@angular/router';

export class LowerCaseUrlSerializer extends DefaultUrlSerializer {
    parse(url: string): UrlTree {
        return super.parse(url.toLowerCase());
    }
}

export const routes: Routes = [
    { path: 'pagenotfound', component: PageNotFoundComponent },
    { path: 'login', loadChildren: './Login/login.module#LoginModule' },
    { path: 'login/:systemid', loadChildren: './Login/login.module#LoginModule' },
    { path: 'login/:redirected', loadChildren: './Login/login.module#LoginModule' },
    { path: 'signup', loadChildren: './SignUp/signup.module#SignupModule' },
    { path: 'atpar', loadChildren: './Home/home.module#HomeModule' },
    { path: 'forgot-password', loadChildren: './ForgotPassword/forgot.module#ForgotModule' },
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: '**', redirectTo: 'pagenotfound', pathMatch: 'full' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: [
        {
            provide: UrlSerializer,
            useClass: LowerCaseUrlSerializer
        }
    ],
})

export class AppRoutingModule { }


