﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'atparx-dept-location-alloc.component.html'
})

export class DepartmentLocationAllocationComponent {

}