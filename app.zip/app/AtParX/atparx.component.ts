﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'atparx.component.html'
})

export class AtParXComponent {

}