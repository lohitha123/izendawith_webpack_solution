﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';


@Component({
   
    templateUrl: 'atparx-processes.component.html'
})

export class ProcessesComponent {
    atparXAppId: number = EnumApps.Pharmacy;
}