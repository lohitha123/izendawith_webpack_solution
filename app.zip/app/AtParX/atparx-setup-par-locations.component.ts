﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'atparx-setup-par-locations.component.html'
})

export class SetupParLocationsComponent {

}