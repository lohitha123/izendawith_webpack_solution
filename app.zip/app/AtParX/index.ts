﻿
//export * from './atparx-routing.module';
//export * from './atparx.module';

export * from './atparx.component';

export * from './atparx-create-orders.component';
export * from './atparx-dept-device-alloc.component';
export * from './atparx-dept-location-alloc.component';
export * from './atparx-dept-user-alloc.component';
export * from './atparx-manage-par-location.component';
export * from './atparx-processes.component';
export * from './atparx-setup-depts.component';
export * from './atparx-setup-dropoff-location.component';
export * from './atparx-setup-par-locations.component';
export * from './atparx-setup-reasons.component';
export * from './atparx-user-parameters.component';
export * from './atparx-dept-user-alloc-home.component'
export * from './atparx-dept-user-alloc-assign.component'

