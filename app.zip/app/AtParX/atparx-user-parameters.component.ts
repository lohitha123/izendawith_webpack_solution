﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';


@Component({
  
    templateUrl: 'atparx-user-parameters.component.html'
})

export class UserParametersComponent {
    atparXAppId: number = EnumApps.Pharmacy;
}