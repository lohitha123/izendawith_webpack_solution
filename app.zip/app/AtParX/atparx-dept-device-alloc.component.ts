﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';

@Component({
   
    templateUrl: 'atparx-dept-device-alloc.component.html'
})

export class DepartmentAtParxDeviceAllocationComponent {
    atParXAppId: number = EnumApps.Pharmacy;

}