﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'atparx-setup-dropoff-location.component.html'
})

export class SetupDropOffLocationComponent {

}