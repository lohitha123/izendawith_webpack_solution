﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'atparx-manage-par-location.component.html'
})

export class ManageParLocationComponent {

}