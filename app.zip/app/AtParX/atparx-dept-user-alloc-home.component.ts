﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';


@Component({
   
    templateUrl: 'atparx-dept-user-alloc-home.component.html'
})

export class DepartmentUserAllocationHomeComponent {
    atParXAppId: number = EnumApps.Pharmacy;
}