﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'atparx-setup-depts.component.html'
})

export class SetupDepartmentsComponent {

}