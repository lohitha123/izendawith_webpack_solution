﻿import { Component } from '@angular/core';


@Component({
    templateUrl: 'deliver-shiptoid-allocation-for-delivery-of-stock-items.component.html'
})

export class ShipToIdAllocationForDeliveryOfStockItemsComponent {
    isVisible: boolean = false;

    getAllBUnits() {
        this.isVisible = true;
       
    }
} 
