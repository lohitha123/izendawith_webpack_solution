﻿import { Component } from '@angular/core';


@Component({
    templateUrl: 'deliver-productivity-report.component.html'
})

export class ProductivityReportComponent {

}