﻿import { Component } from '@angular/core';


@Component({
    templateUrl: 'deliver-delivery-report.component.html'
})

export class DeliveryReportComponent {

} 
