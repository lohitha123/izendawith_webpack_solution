﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';

@Component({
    templateUrl: 'deliver-allocate-location-groups.component.html'
})

export class AllocateLocationGroupsComponent {
    deliverAppId: number = EnumApps.Deliver;
} 
