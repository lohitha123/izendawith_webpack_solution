﻿import { Component } from '@angular/core';


@Component({
    templateUrl: 'deliver-exclude-locations.component.html'
})

export class ExcludeLocationsComponent {
    showGrid: boolean = false;
    BindGrid()
    {
        this.showGrid = true;
    }
} 
