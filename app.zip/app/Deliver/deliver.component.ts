﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'deliver.component.html'
})


export class DeliverComponent { }