﻿import { Component } from '@angular/core';


@Component({
    templateUrl: 'deliver-daily-user-activity.component.html'
})

export class DailyUserActivityComponent {

} 
