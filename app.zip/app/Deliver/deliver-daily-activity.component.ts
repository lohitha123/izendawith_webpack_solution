﻿import { Component } from '@angular/core';


@Component({
    templateUrl: 'deliver-daily-activity.component.html'
})

export class DailyActivityComponent {

} 
