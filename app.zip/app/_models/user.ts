﻿export class User {
    username: string;
    password: string;
    firstName: string;
    lastName: string;
}