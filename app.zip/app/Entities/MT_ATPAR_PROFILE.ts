export class MT_ATPAR_PROFILE {
    public PROFILE_ID: string;
    public PROFILE_DESCRIPTION: string;
}