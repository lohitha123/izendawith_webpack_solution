﻿
export class MT_ATPAR_PROCESS_SCHEDULER {
    public ORG_GROUP_ID: string
    public SCHEDULE_ID: string
    public SCHEDULE_DAY: number;
    public SCHEDULE_TIME: string;
    public CHK_MON: boolean;
    public  CHK_TUE : boolean;
    public  CHK_WED : boolean;
    public  CHK_THR : boolean;
    public CHK_FRI: boolean;
    public CHK_SAT: boolean;
    public CHK_SUN: boolean;
    public SNo: number;
}