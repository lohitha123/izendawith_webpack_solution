export class MT_PKPL_BU_ALLOCATION {
    public BUSINESS_UNIT: string;
    public USER_ID: string;
    public UPDATE_DATE?: Date;
    public UPDATE_USER_ID: string;
}