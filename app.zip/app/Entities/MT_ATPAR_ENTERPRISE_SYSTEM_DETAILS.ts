export class MT_ATPAR_ENTERPRISE_SYSTEM_DETAILS {
    public ENTERPRISE_SYSTEM: string;
    public TYPE: string;
    public ENTERPRISE_VERSION: string;
    public DOWNLOAD_FROM: string;
    public UPLOAD_TO: string;
}