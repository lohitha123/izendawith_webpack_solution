export class MT_ATPAR_STATUS {
    public STATUS_CODE: number;
    public STATUS_MESSAGE: string;
    public STATUS_SOLUTION: string;
    public ONLY_CLIENT: boolean;
    public LANG_ID?: number;
}