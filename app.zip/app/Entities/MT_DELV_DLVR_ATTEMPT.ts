export class MT_DELV_DLVR_ATTEMPT {
    public TRANSACTION_ID: number;
    public ATTEMPT_DATE:  Date;
    public COMMENT: string;
}