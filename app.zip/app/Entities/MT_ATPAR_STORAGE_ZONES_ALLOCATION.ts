export class MT_ATPAR_STORAGE_ZONES_ALLOCATION {
    public APP_ID: number;
    public ORG_GROUP_ID: string;
    public STORAGE_ZONE_ID: string;
    public USER_ID: string;
    public LAST_UPDATE_DATE:  Date;
    public LAST_UPDATE_USER: string;
}