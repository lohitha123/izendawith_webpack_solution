export class MT_ATPAR_LATEST_VALUES {
    public APP_ID: number;
    public FIELD_ID: string;
    public LATEST_VALUE?: number;
}