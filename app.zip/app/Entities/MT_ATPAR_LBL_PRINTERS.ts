export class MT_ATPAR_LBL_PRINTERS {
    public CODE: string;
    public NAME: string;
    public TYPE: string;
    public MANUFACTURER: string;
    public UPDATE_DATE:  Date;
    public UPDATE_USER_ID: string;
    public STATUS: string;
}