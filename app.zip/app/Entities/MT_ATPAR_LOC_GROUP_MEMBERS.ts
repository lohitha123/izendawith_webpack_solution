export class MT_ATPAR_LOC_GROUP_MEMBERS {
    public ORG_GROUP_ID: string;
    public LOC_GROUP_ID: string;
    public ORG_ID: string;
    public LOCATION_ID: string;
    public LOC_DESCR: string;
    public LAST_UPDATE_DATE:  Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
    public TYPE: string;
}