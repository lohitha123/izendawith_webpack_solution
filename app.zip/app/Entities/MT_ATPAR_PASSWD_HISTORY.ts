export class MT_ATPAR_PASSWD_HISTORY {
    public USER_ID: string;
    public OLD_PASSHASH: string;
    public UPDATE_DATE:  Date;
}