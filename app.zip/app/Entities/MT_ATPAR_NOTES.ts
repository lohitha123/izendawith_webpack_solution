export class MT_ATPAR_NOTES {
    public KEY_1: string;
    public KEY_2: string;
    public KEY_3: string;
    public KEY_4: string;
    public KEY_5: string;
    public KEY_6: string;
    public KEY_7: string;
    public KEY_8: string;
    public KEY_9: string;
    public KEY_10: string;
    public KEY_11: string;
    public KEY_12:  Date;
    public KEY_13:  Date;
    public APP_ID: number;
    public SCREEN_NAME: string;
    public TRANS_ID: number;
    public CODE: string;
    public NOTES: string;
    public DATE_TIME?: Date;
}