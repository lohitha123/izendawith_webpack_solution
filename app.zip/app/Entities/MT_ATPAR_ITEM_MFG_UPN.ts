export class MT_ATPAR_ITEM_MFG_UPN {
    public ID: number;
    public ORG_GROUP_ID: string;
    public ITEM_ID: string;
    public MFG_ITEM_ID: string;
    public MANUFACTURER: string;
    public UOM: string;
    public UPN: string;
}