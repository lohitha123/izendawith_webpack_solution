export class MT_ATPAR_LOGIN_HISTORY {
    public USER_ID: string;
    public DEVICE_ID: string;
    public DEVICE_TOKEN: string;
    public LOGIN_DATE_TIME:  Date;
    public REASON_CODE: string;
    public LAST_CLIENT_ADDRESS: string;
}