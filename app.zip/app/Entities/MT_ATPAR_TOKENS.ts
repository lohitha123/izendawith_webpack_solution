export class MT_ATPAR_TOKENS {
    public ACCESS_TOKEN: string;
    public USER_ID: string;
    public DEVICE_ID: string;
    public EXPIRY_TIME: string;
    public REQUEST_TIME: string;
    public PROFILE_ID: string;
    public IDLE_TIME?: number;
    public isVisible: boolean;
    public PRODUCTS_ACCESS: string;
}