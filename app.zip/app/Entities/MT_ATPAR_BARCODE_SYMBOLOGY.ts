export class MT_ATPAR_BARCODE_SYMBOLOGY {
    public SYMBOLOGY_TYPE: string;
    public BARCODE_LENGTH: number;
    public DESCRIPTION: string;
    public ID_START_POSITION?: number;
    public LENGTH?: number;
    public UPDATE_USERID: string;
    public UPDATE_DATE?: Date;
}


   