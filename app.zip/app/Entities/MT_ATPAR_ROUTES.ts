﻿export class MT_ATPAR_ROUTES {
    public APP_ID: number;
    public MENU_ID: string;
    public MENU_CODE: string;
    public MENU_NAME: string;
    public ROUTE: string;
    public MENU_SUB_GROUP: string;
    public ENTERPRISE_SYSTEM: string;
    public MENU_SEQ_NO: number;
    public AUDIT: string;
    public LAST_UPDATE_DATE: string;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}