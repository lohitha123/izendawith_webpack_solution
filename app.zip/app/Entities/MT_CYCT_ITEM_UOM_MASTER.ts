export class MT_CYCT_ITEM_UOM_MASTER {
    public TRANSACTION_ID: number;
    public ITEM_REC_NUM: string;
    public INV_ITEM_ID: string;
    public UOM: string;
    public CONVERSION_RATE?: number;
    public UOM_TYPE: string;
}