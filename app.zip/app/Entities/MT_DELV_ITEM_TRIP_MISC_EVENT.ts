export class MT_DELV_ITEM_TRIP_MISC_EVENT {
    public TRANSACTION_ID: string;
    public EVENT_ID: number;
    public UPDATE_DATE:  Date;
    public TO_USER_OR_LOCGRP: string;
    public USER_ID: string;
}