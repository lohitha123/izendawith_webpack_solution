export class MT_ATPAR_ORG_GROUP_BUNITS {
    public ORG_GROUP_ID: string;
    public BUSINESS_UNIT: string;
    public BU_TYPE: string;
    public LAST_UPDATE_DATE?: Date;
    public LAST_UPDATE_USERID: string;
    public CHK_VALUE: any;
    public CHK_PrvStatus: any;
    public Description: string;
    
}