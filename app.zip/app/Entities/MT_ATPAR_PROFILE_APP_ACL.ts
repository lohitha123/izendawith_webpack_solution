export class MT_ATPAR_PROFILE_APP_ACL {
    public PROFILE_ID: string;
    public APP_ID: number;
    public CLIENT_USER: string;
    public SERVER_USER: string;
    public LAST_UPDATE_DATE?: Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}