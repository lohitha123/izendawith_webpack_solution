export class MT_ATPAR_USER_ORG_GROUPS {
    public USER_ID: string;
    public ORG_GROUP_ID: string;
    public LAST_UPDATE_DATE?: Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}