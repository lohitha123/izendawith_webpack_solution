export class MT_ATPAR_AUDIT_TEMP {
    public UPDATE_USER_ID: string;
    public UPDATE_DATE:  Date;
    public KEY_1: string;
    public KEY_2: string;
    public FUNCTION_NAME: string;
    public FIELD_NAME: string;
    public OLD_VALUE: string;
    public NEW_VALUE: string;
}