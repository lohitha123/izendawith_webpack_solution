export class MT_ATPAR_APP_LINKED_LABELS {
    public APP_ID: number;
    public LABEL_TYPE: number;
    public LABEL_LNK_TYPE: number;
    public LABEL_LNK_DESCRIPTION: string;
    public LABEL_WIDTH: string;
    public LABEL_Height: string;
    public file: FileList;
    public WIDTH_ID: string;
    public HEIGHT_ID: string;
}
