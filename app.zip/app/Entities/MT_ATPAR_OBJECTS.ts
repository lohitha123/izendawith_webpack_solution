export class MT_ATPAR_OBJECTS {
    public APP_ID: number;
    public TABLE_NAME: string;
    public TABLE_TYPE: string;
    public PURGE_FLAG: string;
    public CONDITION_COLUMN: string;
    public COMMENTS: string;
    public UPDATE_DATE?: Date;
    public UPDATE_USER: string;
}