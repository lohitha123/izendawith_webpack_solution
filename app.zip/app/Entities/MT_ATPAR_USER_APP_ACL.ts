export class MT_ATPAR_USER_APP_ACL {
    public USER_ID: string;
    public ROLE_ID: string;
    public APP_ID: number;
}