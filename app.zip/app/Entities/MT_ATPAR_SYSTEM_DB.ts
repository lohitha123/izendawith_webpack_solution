﻿export class MT_ATPAR_SYSTEM_DB {
    public SYSTEM_ID: string;
    public SERVER: string;
    public USERID: string;
    public PASSWORD: string;
    public DATASOURCE: string;
    public SYSTEM_NAME: string;
}