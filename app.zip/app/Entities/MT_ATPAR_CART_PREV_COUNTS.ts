export class MT_ATPAR_CART_PREV_COUNTS {
    public TRANSACTION_ID: number;
    public ITEM_ID: string;
    public COMPARTMENT: string;
    public COUNT_QTY?: number;
}