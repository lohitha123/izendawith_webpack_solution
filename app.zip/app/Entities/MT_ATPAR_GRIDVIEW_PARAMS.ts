﻿export class MT_ATPAR_GRIDVIEW_PARAMS {
    public CHECKVALUE: any;
    public OPTION: string;
    public MENU: string;
    public ORDER: any;
    public PARAM_ID: any;

}