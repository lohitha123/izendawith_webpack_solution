export class MT_AP_PARAMETER_PROCESS {
    public PARAM_ID: string;
    public PARAM_APP_ID: number;
    public PARAM_HOSPGROUP: string;
    public PARAM_INTERFACE_TYPE: string;
    public PARAM_VALUE: string;
}