export class MT_ATPAR_STORAGE_ZONE {
    public ORG_GROUP_ID: string;
    public STORAGE_ZONE_ID: string;
    public STORAGE_ZONE_DESCR: string;
    public STATUS: boolean;
    public LAST_UPDATE_DATE:  Date;
    public LAST_UPDATE_USER: string;
}