export class MT_ATPAR_JOB_SCHEDULES {
    public SERVICE_NAME: string;
    public JOB_ID: string;
    public SCHEDULE_ID: string;
    public STATUS?: boolean;
    public USER_ID: string;
    public LAST_UPDATE_DATE?: Date;
}