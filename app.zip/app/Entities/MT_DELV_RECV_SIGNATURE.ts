export class MT_DELV_RECV_SIGNATURE {
    public SIGNATURE_ID: number;
    public SIGNATURE: string;
}