export class MT_AP_INTERFACE_TYPE {
    public APP_ID: number;
    public INTERFACE_TYPE: string;
    public INTERFACE_DESCRIPTION: string;
}