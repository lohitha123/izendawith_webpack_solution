export class MT_ATPAR_MENUS {
    public APP_ID: number;
    public APP_NAME: string;
    public MENU_ID: string;
    public MENU_CODE: string;
    public MENU_SUB_GROUP: string;
    public ENTERPRISE_SYSTEM: string;
    public MENU_NAME: string;
    public MENU_SEQ_NO?: number;
    public AUDIT: string;
    public LAST_UPDATE_DATE?: Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
    public MENUS_FRIENDLYNAME: string;
    public checkvalue: boolean;
    public UPDATE_DELETE: string;


}