export class MT_AP_ORDER_TBL_ID {
    public APP_ID: number;
    public ORDER_ID?: number;
}