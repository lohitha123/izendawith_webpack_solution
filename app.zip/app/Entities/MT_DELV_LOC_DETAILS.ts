export class MT_DELV_LOC_DETAILS {
    public ORG_GROUP_ID: string;
    public DROP_OFF_LOCATION_ID: string;
    public LOCATION_DESC: string;
    public STATUS: boolean;
    public LAST_UPDATE_DATE:  Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}