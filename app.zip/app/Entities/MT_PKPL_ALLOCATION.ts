export class MT_PKPL_ALLOCATION {
    public BUSINESS_UNIT: string;
    public LOCATION: string;
    public USER_ID: string;
    public DESCR: string;
    public UPDATE_DATE?: Date;
    public SETID: string;
}