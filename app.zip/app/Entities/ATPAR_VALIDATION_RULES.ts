﻿export class ATPAR_VALIDATION_RULES {
    status: Boolean = false;
    validationFormat: any;
    ValidationType: string;
    ErrorMessage: string;
    //Helptext: string;
    order: number;
    showDiv: boolean = true;
    //showerror: boolean = false;
}
//order:number
//paramvalue:string
//showdiv:boolean =true;