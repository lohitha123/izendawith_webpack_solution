﻿export class MT_ATPAR_APP_GROUP {
    public GROUP_ID: number;
    public GROUP_NAME: string;
    public SEQ_NO: number;
    public IMAGE_PATH: string;
}