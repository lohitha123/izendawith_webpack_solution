export class MT_DELV_SHIPTO_ID_ALLOCATION {
    public ORG_GROUP_ID: string;
    public ORG_ID: string;
    public SHIPTO_ID: string;
}