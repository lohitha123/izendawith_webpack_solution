export class MT_ASMT_AUDIT_DETAIL {
    public ORG_GROUP_ID: string;
    public TRANSACTION_ID: number;
    public KEY_1: string;
    public KEY_2: string;
    public KEY_3: string;
    public KEY_4: string;
    public FIELD_NAME: string;
    public OLD_VALUE: string;
    public NEW_VALUE: string;
}