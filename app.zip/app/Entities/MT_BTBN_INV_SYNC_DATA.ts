export class MT_BTBN_INV_SYNC_DATA {
    public USER_ID: string;
    public DEVICE_ID: string;
    public UPDATE_DATE:  Date;
    public SYNC_DATA: string;
}