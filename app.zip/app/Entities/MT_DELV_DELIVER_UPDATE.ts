export class MT_DELV_DELIVER_UPDATE {
    public KEY_1: string;
    public KEY_2: number;
    public KEY_3: number;
}