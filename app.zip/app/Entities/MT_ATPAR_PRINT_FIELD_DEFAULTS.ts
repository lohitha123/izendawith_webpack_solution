export class MT_ATPAR_PRINT_FIELD_DEFAULTS {
    public APP_ID: number;
    public OBJECT_ID: string;
    public LINE_NO: number;
    public FIELD_NAME: string;
    public DISPLAY_NAME: string;
    public FIELD_SIZE: number;
    public SECTION: string;
    public FIELD_GROUP: string;
    public FIELD_TYPE: string;
}