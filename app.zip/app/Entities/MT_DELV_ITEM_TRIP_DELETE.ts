export class MT_DELV_ITEM_TRIP_DELETE {
    public TRANSACTION_ID: number;
    public EVENT_ID: number;
    public UPDATE_DATE:  Date;
    public USER_ID: string;
}