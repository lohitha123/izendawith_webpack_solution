export class MT_CRCT_CRITICAL_ITEMS {
    public BUSINESS_UNIT: string;
    public CART_ID: string;
    public ITEM_ID: string;
}