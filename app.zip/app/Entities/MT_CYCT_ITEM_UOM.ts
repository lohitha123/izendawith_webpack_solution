export class MT_CYCT_ITEM_UOM {
    public ITEM_REC_NUM: string;
    public USER_ID: string;
    public UOM: string;
    public CONVERSION_RATE?: number;
    public BUSINESS_UNIT: string;
    public EVENT_ID: string;
    public INV_ITEM_ID: string;
    public UOM_TYPE: string;
}