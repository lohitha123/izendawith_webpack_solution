﻿export class MT_ATPAR_USER_PROFILE_APP_ACL {
    public PROFILE_ID: string;
    public LDAP_USER: string;
    public APP_ID: number;
    public SERVER_USER: string;
    public CLIENT_USER: string;
}