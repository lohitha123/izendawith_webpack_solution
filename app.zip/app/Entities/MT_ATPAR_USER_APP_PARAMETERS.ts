export class MT_ATPAR_USER_APP_PARAMETERS {
    public APP_ID: number;
    public USER_ID: string;
    public PARAMETER_ID: string;
    public PARAMETER_VALUE: string;
    public LAST_UPDATE_DATE?: Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}