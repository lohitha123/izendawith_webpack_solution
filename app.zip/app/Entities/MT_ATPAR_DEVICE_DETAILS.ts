export class MT_ATPAR_DEVICE_DETAILS {
    public DEVICE_ID: string;
    public DESCRIPTION: string;
    public MAC_ADDRESS: string;
    public STATUS: boolean;
}