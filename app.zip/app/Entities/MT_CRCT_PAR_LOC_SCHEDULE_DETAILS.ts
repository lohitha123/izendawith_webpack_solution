export class MT_CRCT_PAR_LOC_SCHEDULE_DETAILS {
    public ORG_GROUP_ID: string;
    public ORG_ID: string;
    public PAR_LOC_ID: string;
    public SCHEDULE_ID: string;
    //public ROW_INDEX: number;
    //    public CHK_VALUE: boolean = false;
    public CHK_VALUE: string;
   // public SCHEDULES: any;

}