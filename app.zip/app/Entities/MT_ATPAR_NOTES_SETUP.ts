export class MT_ATPAR_NOTES_SETUP {
    public APP_ID: number;
    public SCREEN_NAME: string;
    public NOTES_LABEL: string;
    public NOTES_LIST_DISPLAY: string;
    public NOTES_TABLE_NAME: string;
    public NOTES_FIELD_NAME: string;
    public ALLOW_EDIT_NOTES: string;
    public CAPTURE_CODE: string;
    public APPEND_SELECTED_TEXT: string;
    public UPDATE_DATE?: Date;
    public UPDATE_USER_ID: string;
}