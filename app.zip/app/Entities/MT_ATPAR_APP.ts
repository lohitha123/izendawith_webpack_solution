export class MT_ATPAR_APP {
    public APP_ID: number;
    public APP_NAME: string;
    public APP_IMAGE_PATH: string;
    public GROUP_ID: number;
    public CLIENT_USER: string;
    public SERVER_USER: string;
    public FLAG: boolean;
    public ClientFLAG: boolean;
    public displaymenu: boolean;
    public displayparam: boolean;
    public displayscreen: boolean;
    public errormessage: string;
    public paramDspHide: boolean;
    public menuhide: boolean;
    public hhthide: boolean;
}