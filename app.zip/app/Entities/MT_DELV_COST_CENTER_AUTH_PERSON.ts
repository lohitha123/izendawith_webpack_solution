export class MT_DELV_COST_CENTER_AUTH_PERSON {
    public COST_CENTER_CODE: string;
    public AUTH_USER_ID: string;
    public FIRST_NAME: string;
    public LAST_NAME: string;
    public MIDDLE_NAME: string;
}