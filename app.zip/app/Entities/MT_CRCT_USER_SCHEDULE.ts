export class MT_CRCT_USER_SCHEDULE {
    public BUSINESS_UNIT: string;
    public CART_ID: string;
    public USER_ID: string;
    public DAY: number;
}