export class MT_ATPAR_USER_GROUPS {
    public APP_ID: number;
    public SERVER_USER: string;
    public CLIENT_USER: string;
    public ORG_GROUP_ID: string;
    public LAST_UPDATE_DATE?: Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}