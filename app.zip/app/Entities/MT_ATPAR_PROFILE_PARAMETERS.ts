export class MT_ATPAR_PROFILE_PARAMETERS {
    public PROFILE_ID: string;
    public APP_ID: number;
    public PARAMETER_ID: string;
    public PARAMETER_VALUE: string;
    public LAST_UPDATE_DATE?: Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}