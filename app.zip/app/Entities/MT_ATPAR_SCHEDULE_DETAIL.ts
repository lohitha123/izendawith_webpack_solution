export class MT_ATPAR_SCHEDULE_DETAIL {
    public ORG_GROUP_ID: string;
    public SCHEDULE_ID: string;
    public SCHEDULE_DAY: number;
    public SCHEDULE_TIME:  Date;
}