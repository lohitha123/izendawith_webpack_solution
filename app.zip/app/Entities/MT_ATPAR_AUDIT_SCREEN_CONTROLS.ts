export class MT_ATPAR_AUDIT_SCREEN_CONTROLS {
    public APP_ID: number;
    public FUNCTION_NAME: string;
    public TABLE_NAME: string;
    public FIELD_NAME: string;
    public FIELD_TYPE: string;
    public SUBFUNCTION_NAME: string;
    public KEY_FLAG: string;
    public FRIENDLY_NAME: string;
}