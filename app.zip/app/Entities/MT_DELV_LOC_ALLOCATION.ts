export class MT_DELV_LOC_ALLOCATION {
    public SETID: string;
    public LOCATION: string;
    public USER_ID: string;
    public LOC_ORDER?: number;
    public UPDATE_DATE?: Date;
    public UPDATE_USER_ID: string;
    public DESCRIPTION: string;
}