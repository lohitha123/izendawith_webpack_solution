export class MT_DELV_EXCLUDE_LOC {
    public SETID: string;
    public LOCATION: string;
    public UPDATE_DATE?: Date;
    public UPDATE_USER_ID: string;
}