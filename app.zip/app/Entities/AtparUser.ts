﻿export class AtparUser {
    
    public USER_ID: string = "";
    public PASSHASH: string = "";
    public FIRST_NAME: string;
    public LAST_NAME: string;
    public MIDDLE_INITIAL: string;
    public EMAIL_ID: string;
    public PHONE1: number;
    public PHONE2: number;
    public FAX: string;
    public PAGER: string;
}