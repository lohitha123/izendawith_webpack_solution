export class MT_ATPAR_DEVIATION {
    public BUSINESS_UNIT: string;
    public APP_ID: number;
    public KEY_1: number;
    public KEY_2: number;
    public KEY_3: number;
    public KEY_4: string;
    public KEY_5: string;
    public KEY_6: string;
    public UPDATE_DATE:  Date;
    public REPORT_DATA_1?: number;
    public REPORT_DATA_2?: number;
    public REPORT_DATA_3?: number;
    public REPORT_DATA_4?: number;
    public REPORT_DATA_5?: number;
    public REPORT_DATA_6: string;
    public REPORT_DATA_7: string;
    public REPORT_DATA_8: string;
    public REPORT_DATA_9: string;
    public REPORT_DATA_10: string;
    public REPORT_DATA_11?: Date;
    public USER_ID: string;
    public REPORT_DATA_12: string;
    public REPORT_DATA_13: string;
    public REPORT_DATA_14: string;
    public REPORT_DATA_15: string;
}