export class MT_ATPAR_PROFILE_MENU {
    public PROFILE_ID: string;
    public APP_ID: number;
    public MENU_CODE: string;
    public MENU_SEQ_NO?: number;
    public LAST_UPDATE_DATE?: Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}