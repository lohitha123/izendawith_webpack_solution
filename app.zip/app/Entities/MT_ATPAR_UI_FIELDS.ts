export class MT_ATPAR_UI_FIELDS {
    public APP_ID: number;
    public SCREEN_NAME: string;
    public FIELD_NAME: string;
    public FIELD_DESCR: string;
    public DISPLAY_FLAG: string;
    public EDIT_FLAG: string;
    public SCAN_ORDER?: number;
    public MANDATORY_FLAG: string;
    public IS_DISPLAY: boolean;
    public IS_EDIT: boolean;
    public SCANORDER_ID: string;
}