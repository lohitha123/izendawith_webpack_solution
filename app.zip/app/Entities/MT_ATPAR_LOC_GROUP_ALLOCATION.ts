export class MT_ATPAR_LOC_GROUP_ALLOCATION {
    public APP_ID: number;
    public ORG_GROUP_ID: string;
    public LOC_GROUP_ID: string;
    public USER_ID: string;
    public LAST_UPDATE_DATE:  Date;
    public LAST_UPDATE_USER: string;
    public LAST_CLIENT_ADDRESS: string;
}