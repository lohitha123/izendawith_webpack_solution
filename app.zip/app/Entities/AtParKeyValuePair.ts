﻿export class AtParKeyValuePair {

    public ID: string;
    public Value: string;


}