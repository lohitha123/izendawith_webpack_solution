export class MT_ATPAR_SIGNATURE {
    public APP_ID: number;
    public SIGNATURE_ID: number;
    public SIGNATURE: string;
}