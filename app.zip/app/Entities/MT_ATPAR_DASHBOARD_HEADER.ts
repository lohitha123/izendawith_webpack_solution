export class MT_ATPAR_DASHBOARD_HEADER {
    public DASHBOARD_ID: string;
    public NAME: string;
    public LAYOUT_ROWS: number;
    public LAYOUT_COLUMNS: number;
    public UPDATE_USER_ID: string;
    public UPDATE_DATE?: Date;
}