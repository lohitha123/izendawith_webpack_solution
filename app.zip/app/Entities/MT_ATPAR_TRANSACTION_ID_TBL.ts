export class MT_ATPAR_TRANSACTION_ID_TBL {
    public APP_ID: number;
    public TRANSACTION_ID?: number;
}