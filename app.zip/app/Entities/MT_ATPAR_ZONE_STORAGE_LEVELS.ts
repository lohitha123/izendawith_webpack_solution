export class MT_ATPAR_ZONE_STORAGE_LEVELS {
    public ORG_GROUP_ID: string;
    public STORAGE_ZONE_ID: string;
    public ORG_ID: string;
    public STORAGE_AREA: string;
    public STOR_LEVEL_1: string;
    public STOR_LEVEL_2: string;
    public STOR_LEVEL_3: string;
    public STOR_LEVEL_4: string;
    public LAST_UPDATE_DATE:  Date;
    public LAST_UPDATE_USER: string;
    public CHK_VALUE: number;
    public CHK_ALLOCATED: string;
    public checkvalue: boolean;
    public SNo: number;
    public PERFORM_ACTION: number;
}