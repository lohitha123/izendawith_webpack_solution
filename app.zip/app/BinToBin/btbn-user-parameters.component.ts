﻿import { Component } from '@angular/core';
import { EnumApps } from '../Shared/AtParEnums';

@Component({
  
    templateUrl: 'btbn-user-parameters.component.html'
})

export class UserParametersComponent {
    btbnAppId: number = EnumApps.BinToBin;
}