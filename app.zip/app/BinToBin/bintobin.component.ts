﻿import { Component } from '@angular/core';


@Component({
   
    templateUrl: 'bintobin.component.html'
})


export class BinToBinComponent { }