﻿
declare var require: any;